﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Sqlite_Шумовы;

public partial class ShumovVladContext : DbContext
{
    public ShumovVladContext()
    {
    }

    public ShumovVladContext(DbContextOptions<ShumovVladContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<ProductSGroupы> ProductSGroupыs { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlite("Data Source=D:\\ShumovVlad.db");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Product>(entity =>
        {
            entity.ToTable("products");

            entity.HasIndex(e => e.Id, "IX_products_id").IsUnique();

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.PricePurchase)
                .HasColumnType("NUMERIC")
                .HasColumnName("Price_purchase");
            entity.Property(e => e.PriceSale)
                .HasColumnType("NUMERIC")
                .HasColumnName("Price_sale");
            entity.Property(e => e.Product1).HasColumnName("Product");
            entity.Property(e => e.ProductGroup).HasColumnName("Product_group");

            entity.HasOne(d => d.ProductGroupNavigation).WithMany(p => p.Products)
                .HasForeignKey(d => d.ProductGroup)
                .OnDelete(DeleteBehavior.ClientSetNull);
        });

        modelBuilder.Entity<ProductSGroupы>(entity =>
        {
            entity.ToTable("Product's groupы");

            entity.HasIndex(e => e.Group, "IX_Product's groupы_Group").IsUnique();

            entity.HasIndex(e => e.Id, "IX_Product's groupы_id").IsUnique();

            entity.Property(e => e.Id).HasColumnName("id");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
