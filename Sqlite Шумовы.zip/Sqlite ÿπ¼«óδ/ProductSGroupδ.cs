﻿using System;
using System.Collections.Generic;

namespace Sqlite_Шумовы;

public partial class ProductSGroupы
{
    public int Id { get; set; }

    public string Group { get; set; } = null!;

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
