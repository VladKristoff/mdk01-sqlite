﻿using System;
using System.Collections.Generic;

namespace Sqlite_Шумовы;

public partial class Product
{
    public int Id { get; set; }

    public string Product1 { get; set; } = null!;

    public int ProductGroup { get; set; }

    public int PricePurchase { get; set; }

    public int PriceSale { get; set; }

    public virtual ProductSGroupы ProductGroupNavigation { get; set; } = null!;
}
